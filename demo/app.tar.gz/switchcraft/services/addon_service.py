import json
import logging
import importlib.util
import shutil
import zipfile
import tempfile
import os
from pathlib import Path

logger = logging.getLogger(__name__)

# Legacy compatibility: singleton instance for static method calls
_addon_service_instance = None

def _get_addon_service_instance():
    global _addon_service_instance
    if _addon_service_instance is None:
        _addon_service_instance = AddonService()
    return _addon_service_instance

class AddonService:
    def __init__(self):
        # Use static method for directory to allow easier mocking
        self.addons_dir = self.get_addon_dir()
        self.loaded_addons = {} # id -> module/class info

    @staticmethod
    def get_addon_dir():
        """Returns the base directory for addons."""
        from switchcraft import IS_WEB
        import sys
        if IS_WEB:
            # In Web/Pyodide, we use the 'switchcraft.addons' package directory
            # assuming addons are baked into the package.
            # Using __file__ to locate the services directory, then up to package, then addons.
            # src/switchcraft/services/addon_service.py -> src/switchcraft
            base = Path(__file__).parent.parent
            path = base / "addons"
            # Ensure it exists (it should if baked properly)
            if not path.exists():
                path.mkdir(parents=True, exist_ok=True)
            return path

        path = Path.home() / ".switchcraft" / "addons"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def read_manifest(addon_dir):
        """Reads and validates the manifest.json file from an addon directory."""
        manifest = addon_dir / "manifest.json"
        if not manifest.exists():
            return None

        try:
            with open(manifest, "r") as f:
                data = json.load(f)
                if "id" in data:
                    return data
        except (FileNotFoundError, json.JSONDecodeError, OSError) as e:
            logger.warning(f"Error reading addon manifest at {addon_dir}: {e}")
        return None

    def _iter_addons(self):
        """
        Yields (path, manifest_data) for all valid addons found.
        """
        for d in self.addons_dir.iterdir():
            if d.is_dir():
                data = self.read_manifest(d)
                if data:
                    yield d, data

    def list_addons(self):
        """
        Scans addons directory for valid manifests.
        Returns list of dicts.
        """
        addons = []
        for d, data in self._iter_addons():
             data["_path"] = str(d) # internal use
             addons.append(data)
        return addons

    def load_addon_view(self, addon_id):
        """
        Dynamically loads the addon view class.
        Returns the Class object (not instance).
        """
        # Find path
        addon_path = None
        manifest_data = None

        for d, data in self._iter_addons():
             if data.get("id") == addon_id:
                 addon_path = d
                 manifest_data = data
                 break

        if not addon_path:
            raise FileNotFoundError(f"Addon {addon_id} not found")

        entry_point = manifest_data.get("entry_point", "view.py")
        class_name = manifest_data.get("class_name", "AddonView")

        file_path = addon_path / entry_point
        if not file_path.exists():
             raise FileNotFoundError(f"Entry point {entry_point} not found for addon {addon_id}")

        # Magic import
        try:
            spec = importlib.util.spec_from_file_location(f"addons.{addon_id}", file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            if hasattr(module, class_name):
                return getattr(module, class_name)
            else:
                raise AttributeError(f"Class {class_name} not found in {entry_point}")
        except Exception as e:
            logger.error(f"Failed to load addon {addon_id}: {e}")
            raise e

    def import_addon_module(self, addon_id, module_name):
        """
        Attempts to import a specific module from an addon.
        Returns the module object or None if not found/error.
        """
        # Find addon path
        addon_path = None
        for d, data in self._iter_addons():
             if data.get("id") == addon_id:
                 addon_path = d
                 break

        if not addon_path:
            return None

        # Resolve file path from module name (dotted)
        # e.g. "analyzers.universal" -> "analyzers/universal.py"
        rel_path = module_name.replace(".", "/") + ".py"
        file_path = addon_path / rel_path

        if not file_path.exists():
            # Try as package (dir/__init__.py)
            rel_path = module_name.replace(".", "/") + "/__init__.py"
            file_path = addon_path / rel_path
            if not file_path.exists():
                return None

        try:
            name = f"addons.{addon_id}.{module_name}"
            spec = importlib.util.spec_from_file_location(name, file_path)
            if not spec or not spec.loader:
                return None
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except Exception as e:
            logger.error(f"Failed to import addon module {name}: {e}")
            return None

    def install_addon(self, zip_path):
        """
        Installs an addon from a zip file.
        Expects zip to contain manifest.json at root or in a subfolder.
        """
        zip_path = Path(zip_path)
        if not zip_path.exists():
            raise FileNotFoundError(f"Zip not found: {zip_path}")

        try:
            with zipfile.ZipFile(zip_path, 'r') as z:
                # Validate manifest
                files = z.namelist()
                manifest_path = None

                # Unified Manifest Search (Recursive & Case-Insensitive)
                # This replaces the brittle "root-first then check-subdir" logic
                for file_in_zip in files:
                    # Normalize path separators
                    normalized = file_in_zip.replace('\\', '/')
                    parts = normalized.split('/')

                    # Check if filename is manifest.json (case-insensitive)
                    if parts[-1].lower() == 'manifest.json':
                        # Limit depth to avoid deep nesting if necessary (e.g., max depth 3)
                         if len(parts) <= 4:
                             manifest_path = file_in_zip
                             break

                if not manifest_path:
                    # Provide helpful error message listing contents
                    all_files_list = [f for f in files]
                    truncated_list = all_files_list[:10]
                    if len(all_files_list) > 10:
                        truncated_list.append(f"... ({len(all_files_list) - 10} more)")

                    raise Exception(
                        f"Invalid addon: manifest.json not found in ZIP archive.\n"
                        f"The addon ZIP must contain a manifest.json file.\n"
                        f"Files found in ZIP: {', '.join(truncated_list) if truncated_list else 'none'}"
                    )

                # Check ID from manifest (use found path, not hardcoded)
                with z.open(manifest_path) as f:
                    try:
                        data = json.load(f)
                    except json.JSONDecodeError as e:
                        raise Exception(f"Invalid manifest.json: JSON parse error - {e}")

                    addon_id = data.get("id")
                    if not addon_id:
                        raise Exception("Invalid manifest.json: missing required field 'id'")

                # Extract
                target = self.addons_dir / addon_id
                if target.exists():
                    shutil.rmtree(target) # Overwrite
                target.mkdir()
                target_resolved = target.resolve()

                # Compute manifest directory to rebase extraction
                # If manifest is "A/B/manifest.json", manifest_dir is "A/B"
                manifest_path_normalized = manifest_path.replace('\\', '/')
                manifest_dir = os.path.dirname(manifest_path_normalized) if '/' in manifest_path_normalized else ""

                # Update error message to indicate if manifest was found in subdirectory
                manifest_location_msg = f" (found in subdirectory: {manifest_dir})" if manifest_dir else ""

                logger.debug(f"Addon extract manifest_dir: '{manifest_dir}'")

                for member in z.infolist():
                    # Normalize path separators for cross-platform compatibility
                    normalized_name = member.filename.replace('\\', '/')

                    # If manifest was in a subdirectory, strip that prefix from all files
                    if manifest_dir:
                        if not normalized_name.startswith(manifest_dir + '/'):
                            continue # Skip files outside the manifest directory
                        # Strip manifest_dir prefix
                        target_name = normalized_name[len(manifest_dir) + 1:]  # +1 for the '/'
                        if not target_name: # Was the directory itself
                            continue
                    else:
                        target_name = normalized_name

                    # Resolve the target path for this member
                    file_path = (target / target_name).resolve()

                    # Ensure the resolved path is within the target directory (prevent Zip Slip)
                    # Use Path.relative_to() which is safer than string prefix checks
                    # It properly handles sibling directories and path traversal attacks
                    try:
                        file_path.relative_to(target_resolved)
                    except ValueError:
                        # Path is outside target directory - Zip Slip attack detected
                        logger.error(f"Security Alert: Attempted Zip Slip with {member.filename} -> {file_path}")
                        continue

                    # Create parent directories
                    file_path.parent.mkdir(parents=True, exist_ok=True)

                    # Extract file
                    if not member.is_dir() and not target_name.endswith('/'):
                        with z.open(member, 'r') as source, open(file_path, 'wb') as dest:
                            shutil.copyfileobj(source, dest)

                logger.info(f"Installed addon: {addon_id}{manifest_location_msg}")
                return True
        except Exception as e:
            logger.error(f"Install failed: {e}")
            raise e

    def delete_addon(self, addon_id):
         # Find and delete
         addons = list(self._iter_addons())
         for d, data in addons:
             if data.get("id") == addon_id:
                 try:
                     shutil.rmtree(d)
                     return True
                 except OSError as e:
                     logger.error(f"Failed to delete addon {addon_id} at {d}: {e}")
         return False

    def is_addon_installed(self, addon_id):
        """
        Determine whether an addon with the given id is installed.

        Parameters:
        	addon_id (str): The addon identifier to look for.

        Returns:
        	`true` if an addon with the given id is installed, `false` otherwise.
        """
        for _, data in self._iter_addons():
            if data.get("id") == addon_id:
                return True
        return False

    @staticmethod
    def is_addon_installed_static(addon_id):
        """
        Check whether an addon with the given identifier is installed.

        Parameters:
            addon_id (str): Addon identifier to check.

        Returns:
            True if an addon with that id is installed, False otherwise.
        """
        return _get_addon_service_instance().is_addon_installed(addon_id)

    def uninstall_addon(self, addon_id):
        """Legacy alias for delete_addon."""
        return self.delete_addon(addon_id)

    def _extract_and_install_zip(self, zip_content, pkg_name, is_source=False, auto_detect=False):
        """Legacy method for tests."""
        # Create a temp zip file and call install_addon
        temp_zip = self.addons_dir / "_temp_install.zip"
        with open(temp_zip, "wb") as f:
            f.write(zip_content)
        try:
            return self.install_addon(str(temp_zip))
        finally:
            if temp_zip.exists():
                temp_zip.unlink()

    # --- Legacy Static Methods ---
    @staticmethod
    def register_addons():
        """Legacy: No-op for backwards compatibility."""
        pass

    @staticmethod
    def set_app_window(window):
        """Legacy: No-op for backwards compatibility."""
        pass

    @staticmethod
    def install_all_missing():
        """Legacy: No-op for backwards compatibility."""
        return True

    def install_from_github(self, addon_id, app_version_tag=None):
        """
        Attempts to download and install an addon from GitHub Releases.
        - app_version_tag: "v2023.10.0". If None, checks current app version.
        - Checks for exact matching tag first.
        - If not found, falls back to 'latest' release with a warning.
        - Looks for 'switchcraft_{addon_id}.zip' asset.
        """
        try:
            import requests
        except ImportError:
            logger.error("requests module not found. Please install it to use this feature.")
            return False, "Python 'requests' module is missing."

        from switchcraft import __version__ as current_app_version

        repo_owner = "FaserF"
        repo_name = "SwitchCraft"
        api_base = f"https://api.github.com/repos/{repo_owner}/{repo_name}"

        target_tag = app_version_tag
        if not target_tag:
            # Construct tag from current version
            # Assuming tags are v<Version>
            target_tag = f"v{current_app_version}"

        logger.info(f"AddonService: Attempting to install '{addon_id}' for tag '{target_tag}'...")

        release_data = None
        used_tag = None
        warning_msg = None

        # 1. Try Specific Tag
        try:
            resp = requests.get(f"{api_base}/releases/tags/{target_tag}", timeout=5)
            if resp.status_code == 200:
                try:
                    release_data = resp.json()
                    used_tag = target_tag
                    logger.info(f"Found specific release: {target_tag}")
                except json.JSONDecodeError as je:
                    logger.warning(f"Invalid JSON in release {target_tag}: {je}")
            else:
                 logger.warning(f"Release {target_tag} not found (Status {resp.status_code}).")
        except Exception as e:
            logger.warning(f"Error checking tag {target_tag}: {e}")

        # 2. Fallback to Latest
        if not release_data:
            logger.info("Falling back to latest release...")
            try:
                resp = requests.get(f"{api_base}/releases/latest", timeout=5)
                if resp.status_code == 200:
                    try:
                        release_data = resp.json()
                        used_tag = release_data.get("tag_name")
                        warning_msg = f"Version mismatch: Installed {addon_id} from {used_tag} (Expected {target_tag}). Compatibility not guaranteed."
                        logger.warning(warning_msg)
                    except (ValueError, json.JSONDecodeError):
                        logger.error("Invalid JSON from latest release.")
                        return False, "Invalid response from GitHub."
                else:
                     logger.error(f"Latest release not found (Status {resp.status_code}).")
                     return False, "Could not find any releases."
            except Exception as e:
                logger.error(f"Error fetching latest release: {e}")
                return False, f"Failed to fetch latest release: {e}"

        if not release_data:
             return False, "No release data found."

        # 3. Find Asset
        # Naming convention: switchcraft_{addon_id}.zip OR {addon_id}.zip
        # Script produces switchcraft_advanced.zip
        asset_url = None
        asset_name = ""

        candidates = [f"switchcraft_{addon_id}.zip", f"{addon_id}.zip"]

        for asset in release_data.get("assets", []):
            if asset.get("name") in candidates:
                asset_url = asset.get("browser_download_url")
                asset_name = asset.get("name")
                break

        if not asset_url:
            msg = f"Asset for {addon_id} not found in release {used_tag}."
            logger.error(msg)
            return False, msg

        # 4. Download and Install
        try:
            logger.info(f"Downloading {asset_name} from {asset_url}...")
            r = requests.get(asset_url, stream=True, timeout=30)
            r.raise_for_status()

            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                    for chunk in r.iter_content(chunk_size=8192):
                        tmp.write(chunk)
                    tmp_path = tmp.name

                self.install_addon(tmp_path)
                logger.info(f"Successfully installed {addon_id} from GitHub.")
                result_msg = f"Installed {addon_id} ({used_tag})."
                if warning_msg:
                    result_msg += f" [Warning: {warning_msg}]"
                return True, result_msg
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    os.remove(tmp_path)

        except Exception as e:
            logger.error(f"Failed to download/install {addon_id}: {e}")
            return False, str(e)