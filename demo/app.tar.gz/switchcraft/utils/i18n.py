import locale
import json
import logging

logger = logging.getLogger(__name__)

# Known parameter explanations (used in GUI for parameter list)
KNOWN_PARAMS = {
    "/S": ("Silent mode", "Stiller Modus - Keine Benutzerinteraktion"),
    "/s": ("Silent mode", "Stiller Modus - Keine Benutzerinteraktion"),
    "/SILENT": ("Silent install", "Stille Installation ohne Dialoge"),
    "/VERYSILENT": ("Very silent install (no progress)", "Komplett stille Installation ohne Fortschrittsanzeige"),
    "/NORESTART": ("Prevent automatic restart", "Automatischen Neustart verhindern"),
    "/SUPPRESSMSGBOXES": ("Suppress message boxes", "Meldungsfenster unterdrücken"),
    "/SP-": ("Disable 'This will install...' prompt", "'Dies wird installieren...' Dialog deaktivieren"),
    "/CLOSEAPPLICATIONS": ("Close running applications", "Laufende Anwendungen schließen"),
    "/RESTARTAPPLICATIONS": ("Restart closed applications", "Geschlossene Anwendungen neu starten"),
    "/NOCANCEL": ("Disable cancel button", "Abbrechen-Button deaktivieren"),
    "/NOICONS": ("Don't create Start Menu icons", "Keine Startmenü-Icons erstellen"),
    "/DIR=": ("Installation directory", "Installationsverzeichnis"),
    "/LOG=": ("Log file path", "Protokolldatei-Pfad"),
    "/LOG": ("Enable logging", "Protokollierung aktivieren"),
    "/FORCECLOSEAPPLICATIONS": ("Force close applications", "Anwendungen erzwingen schließen"),
    "/q": ("Quiet mode (MSI)", "Stiller Modus (MSI)"),
    "/qn": ("Quiet, no UI (MSI)", "Komplett still, keine UI (MSI)"),
    "/qb": ("Basic UI (MSI)", "Basis-UI (MSI)"),
    "/qr": ("Reduced UI (MSI)", "Reduzierte UI (MSI)"),
    "/passive": ("Passive mode, progress only (MSI)", "Passiver Modus, nur Fortschritt (MSI)"),
    "/norestart": ("No restart (MSI)", "Kein Neustart (MSI)"),
    "/l*v": ("Verbose logging (MSI)", "Ausführliche Protokollierung (MSI)"),
    "/i": ("Install (MSI)", "Installieren (MSI)"),
    "/x": ("Uninstall (MSI)", "Deinstallieren (MSI)"),
    "/quiet": ("Quiet mode, no user interaction", "Stiller Modus - Keine Benutzerinteraktion"),
    "/Q": ("Quiet mode", "Stiller Modus"),
    "-quiet": ("Quiet mode", "Stiller Modus"),
    "/qb!": ("Basic UI, no cancel button (MSI)", "Basis-UI, kein Abbrechen-Button (MSI)"),
    "/promptrestart": ("Prompt for restart (MSI)", "Nach Neustart fragen (MSI)"),
    "/forcerestart": ("Force restart (MSI)", "Neustart erzwingen (MSI)"),
    "-silent": ("Silent mode (alternative)", "Stiller Modus (alternativ)"),
    "-q": ("Quiet mode", "Stiller Modus"),
    "-s": ("Silent mode", "Stiller Modus"),
    "--silent": ("Silent mode (GNU style)", "Stiller Modus (GNU-Stil)"),
    "--quiet": ("Quiet mode (GNU style)", "Stiller Modus (GNU-Stil)"),
    "-y": ("Auto-confirm (yes to all)", "Automatische Bestätigung (Ja zu allem)"),
    "/extract": ("Extract only, no install", "Nur extrahieren, nicht installieren"),
    "/D=": ("Destination directory (NSIS)", "Zielverzeichnis (NSIS)"),
    "/COMPONENTS=": ("Select components", "Komponenten auswählen"),
    "/TASKS=": ("Select tasks", "Aufgaben auswählen"),
    "/MERGETASKS=": ("Merge tasks", "Aufgaben zusammenführen"),
    "REBOOT=ReallySuppress": ("Suppress reboot (MSI)", "Neustart unterdrücken (MSI)"),
    "ALLUSERS=1": ("Install for all users (MSI)", "Für alle Benutzer installieren (MSI)"),
    "INSTALLLEVEL=": ("Installation level (MSI)", "Installationsstufe (MSI)"),
    "ADDLOCAL=ALL": ("Install all features (MSI)", "Alle Funktionen installieren (MSI)"),
    "ALLUSERS=2": ("Install for all users if admin, else user (MSI)", "Für alle Benutzer wenn Admin, sonst Benutzer (MSI)"),
    "REBOOT=Force": ("Force reboot (MSI)", "Neustart erzwingen (MSI)"),
    "SKIPCHECK=1": ("Skip environment checks", "Umgebungsprüfungen überspringen"),
    "ALLOWMSI=1": ("Allow MSI installation", "MSI-Installation erlauben"),
    "/f": ("Repair (MSI)", "Reparieren (MSI)"),
    "/j": ("Advertise (MSI)", "Ankündigen/Werben (MSI)"),
    "/a": ("Administrative install (MSI)", "Administrative Installation (MSI)"),
    "/p": ("Apply patch (MSI)", "Patch anwenden (MSI)"),
    "/m": ("Generate MIF file (MSI)", "MIF-Datei generieren (MSI)"),
    "/t": ("Apply transform (MSI)", "Transformation anwenden (MSI)"),
    "/g": ("Language ID (MSI)", "Sprach-ID (MSI)"),
    "/v": ("Pass arguments to MSI (InstallShield)", "Argumente an MSI weitergeben (InstallShield)"),
    "/f1": ("Specify response file path (InstallShield)", "Antwortdatei-Pfad angeben (InstallShield)"),
    "/f2": ("Specify log file path (InstallShield)", "Protokolldatei-Pfad angeben (InstallShield)"),
    "/clone_wait": ("Wait for child processes (InstallShield)", "Auf Child-Prozesse warten (InstallShield)"),
    "/L": ("Language ID (InstallShield)", "Sprach-ID (InstallShield)"),
    "/NCRC": ("Disable CRC check (NSIS)", "CRC-Prüfung deaktivieren (NSIS)"),
    "/uninstall": ("Run uninstaller", "Deinstallationsprogramm ausführen"),
    "/repair": ("Run repair", "Reparatur ausführen"),
    "/layout": ("Create local copy of bundle", "Lokale Kopie des Bundles erstellen"),
    "/sAll": ("Silent install for all features (Adobe)", "Stille Installation aller Funktionen (Adobe)"),
    "/sPB": ("Silent install with progress bar (Adobe)", "Stille Installation mit Fortschrittsbalken (Adobe)"),
    "/rs": ("Reboot suppressed (Adobe)", "Neustart unterdrückt (Adobe)"),
    "/sl": ("Language ID (Adobe)", "Sprach-ID (Adobe)"),
    "-ExecutionPolicy": ("Set execution policy (PS)", "ExecutionPolicy festlegen (PS)"),
    "-NoProfile": ("Don't load user profile (PS)", "Benutzerprofil nicht laden (PS)"),
    "-NonInteractive": ("Non-interactive mode (PS)", "Nicht-interaktiver Modus (PS)"),
    "-WindowStyle": ("Set window style (PS)", "Fensterstil festlegen (PS)"),
    "-File": ("Run script file (PS)", "Skriptdatei ausführen (PS)"),
    "-Command": ("Run command string (PS)", "Befehlsstring ausführen (PS)"),
}


class I18n:
    def __init__(self):
        self.language = self._detect_language()
        self.translations = {}
        self._load_translations()

    def _load_translations(self):
        """Load translations from JSON files in assets/lang."""
        try:
            # Use pathlib for better cross-platform handling
            import sys
            from pathlib import Path

            if getattr(sys, 'frozen', False):
                # PyInstaller: Assets are at root/assets
                base_path = Path(sys._MEIPASS)
                lang_dir = base_path / "assets" / "lang"
            elif sys.platform == "emscripten":
                # Pyodide/WASM: Try to import baked-in translations first (generated during CI)
                try:
                    from switchcraft.utils import wasm_translations
                    self.translations = wasm_translations.TRANSLATIONS
                    logger.info("Loaded baked-in translations for WASM")
                    return
                except ImportError:
                    pass

                # Fallback: Try multiple possible locations
                possible_paths = [
                    Path("switchcraft/assets/lang"),
                    Path("assets/lang"),
                    Path("/home/pyodide/switchcraft/assets/lang"),
                    Path("/assets/lang")
                ]
                lang_dir = Path("switchcraft/assets/lang") # Default
                for p in possible_paths:
                    if p.exists():
                        lang_dir = p
                        break
            else:
                # Dev: src/switchcraft/utils/../assets/lang -> src/switchcraft/assets/lang
                base_path = Path(__file__).parent
                lang_dir = base_path.parent / "assets" / "lang"

            logger.debug(f"Loading translations from: {lang_dir.resolve()}")

            if not lang_dir.exists():
                logger.error(f"Language directory not found: {lang_dir.resolve()}")

            for lang_code in ["en", "de"]:
                file_path = lang_dir / f"{lang_code}.json"
                if file_path.exists():
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            self.translations[lang_code] = json.load(f)
                    except Exception as e:
                         logger.error(f"Failed to load {lang_code} translation: {e}")
                else:
                    logger.warning(f"Translation file missing: {file_path}")

            # Ensure English exists as fallback at minimum
            if "en" not in self.translations:
                self.translations["en"] = {} # Will cause issues but prevents crash

        except Exception as e:
            logger.error(f"Critical i18n error: {e}")

    def _detect_language(self):
        try:
            # 1. Try SwitchCraft Config User Preference first
            from switchcraft.utils.config import SwitchCraftConfig
            user_pref = SwitchCraftConfig.get_value("Language", None)
            if user_pref and user_pref in ["de", "en"]:
                return user_pref

            # 2. Try to get browser language from session (Web mode)
            try:
                browser_lang = SwitchCraftConfig.get_value("browser_language", None)
                if browser_lang and browser_lang in ["de", "en"]:
                    logger.info(f"Using browser language from session: {browser_lang}")
                    return browser_lang
            except Exception:
                pass

            # 3. Try System Locale
            # Windows can return 'de_DE', 'German_Germany', 'de', etc.
            lang = None
            try:
                # locale.getlocale() is preferred but can fail or return (None, None)
                loc = locale.getlocale()
                if loc and loc[0]:
                    lang = loc[0]
            except Exception:
                pass

            if not lang:
                try:
                    # Fallback to default locale
                    loc = locale.getdefaultlocale()
                    if loc and loc[0]:
                        lang = loc[0]
                except Exception:
                    pass

            # 4. Analyze detected system string
            if lang:
                lang = lang.lower()
                if "de_" in lang or "german" in lang or lang == "de":
                    return "de"

        except Exception as e:
            logger.warning(f"Could not detect language: {e}")

        # Default fallback
        return "en"

    def set_language(self, lang_code):
        if lang_code in self.translations:
            self.language = lang_code
        else:
            logger.warning(f"Language {lang_code} not supported, falling back to English.")
            self.language = "en"

    def get(self, key, lang=None, default=None, **kwargs):
        """
        Get translated string.
        Supports explicit language override 'lang'.
        Supports format arguments explicitly passed as kwargs.
        """
        # Try to get language from current config context (SessionStoreBackend)
        try:
            from switchcraft.utils.config import SwitchCraftConfig
            ctx_lang = SwitchCraftConfig.get_value("Language")
            if ctx_lang and ctx_lang != self.language and ctx_lang in self.translations:
                 # Use the language from the current context (User Session)
                 # This allows multi-user language support despite Singleton pattern
                 lang = ctx_lang
        except:
            pass

        target_lang = lang if lang else self.language

        # Get dictionary for target language, fallback to EN
        lang_dict = self.translations.get(target_lang, self.translations.get("en", {}))

        # Get value, fallback to English value, then to default (if provided), else key
        val = lang_dict.get(key)
        if val is None:
             val = self.translations.get("en", {}).get(key)

        if val is None:
            val = default if default is not None else key

        # Format if kwargs provided
        if kwargs and isinstance(val, str):
            try:
                return val.format(**kwargs)
            except Exception as e:
                logger.warning(f"Failed to format string '{key}': {e}")
                return val

        return val

    def get_param_explanation(self, param):
        """Get explanation for a known parameter in current language."""
        if param in KNOWN_PARAMS:
            en, de = KNOWN_PARAMS[param]
            return de if self.language == "de" else en
        # Try partial match (for params like /DIR=path)
        base_param = param.split("=")[0] + "=" if "=" in param else None
        if base_param and base_param in KNOWN_PARAMS:
            en, de = KNOWN_PARAMS[base_param]
            return de if self.language == "de" else en
        return None

i18n = I18n()
