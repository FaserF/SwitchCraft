import customtkinter as ctk
from tkinter import messagebox
import threading
import logging
import shutil
import tempfile
import webbrowser
from pathlib import Path

from switchcraft.utils.i18n import i18n
# from switchcraft.utils.winget import WingetHelper # Moved to Addon

logger = logging.getLogger(__name__)

class WingetView(ctk.CTkFrame):
    def __init__(self, parent, winget_helper, intune_service, notification_service):
        super().__init__(parent)
        self.winget_helper = winget_helper
        self.intune_service = intune_service
        self.notification_service = notification_service
        self.main_app = parent

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.setup_ui()

    def setup_ui(self):
        # Master Layout
        self.panes = ctk.CTkFrame(self, fg_color="transparent")
        self.panes.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.panes.grid_columnconfigure(0, weight=1) # List
        self.panes.grid_columnconfigure(1, weight=2) # Details
        self.panes.grid_rowconfigure(0, weight=1)

        # === Left Pane: Search ===
        left_pane = ctk.CTkFrame(self.panes)
        left_pane.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        left_pane.grid_rowconfigure(2, weight=1)
        left_pane.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left_pane, text="Winget Store", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, pady=10)

        # Filter and Search Bar
        filter_search_frame = ctk.CTkFrame(left_pane, fg_color="transparent")
        filter_search_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 5))

        # Filter dropdown
        self.filter_var = ctk.StringVar(value="All")
        self.filter_dropdown = ctk.CTkOptionMenu(
            filter_search_frame,
            values=["All", "Name", "Package ID", "Publisher"],
            variable=self.filter_var,
            width=100
        )
        self.filter_dropdown.pack(side="left", padx=(0, 5))

        self.search_entry = ctk.CTkEntry(filter_search_frame, placeholder_text=i18n.get("winget_search_placeholder"))
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.search_entry.bind("<Return>", lambda e: self._perform_search())

        ctk.CTkButton(filter_search_frame, text=i18n.get("winget_search_btn"), width=40, command=self._perform_search).pack(side="right")

        # Results count label
        self.results_count_label = ctk.CTkLabel(left_pane, text="", text_color="gray", font=ctk.CTkFont(size=11))
        self.results_count_label.grid(row=2, column=0, sticky="w", padx=10)

        # Results List
        self.results_scroll = ctk.CTkScrollableFrame(left_pane)
        self.results_scroll.grid(row=3, column=0, sticky="nsew", padx=10, pady=(0, 10))

        # Configure row weight for scrollable area
        left_pane.grid_rowconfigure(3, weight=1)

        # Initial placeholder - tell user to search first
        self.lbl_results_placeholder = ctk.CTkLabel(
            self.results_scroll,
            text="Type a search term above to find apps...",
            text_color="gray"
        )
        self.lbl_results_placeholder.pack(pady=20)

        # === Right Pane: Details ===
        self.right_pane = ctk.CTkFrame(self.panes)
        self.right_pane.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        self.right_pane.grid_columnconfigure(0, weight=1)

        self.lbl_details_title = ctk.CTkLabel(self.right_pane, text=i18n.get("manual_select"), font=ctk.CTkFont(size=18, weight="bold"), anchor="w")
        self.lbl_details_title.pack(pady=20, padx=20, fill="x")

        self.details_content = ctk.CTkScrollableFrame(self.right_pane, fg_color="transparent")
        self.details_content.pack(fill="both", expand=True, padx=10, pady=10, anchor="nw")

        # Initial empty state
        self.lbl_empty_state = ctk.CTkLabel(self.details_content, text=i18n.get("winget_search_placeholder"))
        self.lbl_empty_state.pack(pady=20)

        if not self.winget_helper:
            err_bg = ctk.CTkFrame(self.panes, fg_color="#DC3545", height=30)
            err_bg.grid(row=1, column=0, columnspan=2, sticky="ew", pady=5)
            ctk.CTkLabel(err_bg, text="Winget Addon not loaded. Please reinstall addons.", text_color="white").pack()
            self.search_entry.configure(state="disabled")

    def _perform_search(self):
        query = self.search_entry.get().strip()
        if not query:
            return

        filter_by = self.filter_var.get()
        self.results_count_label.configure(text="")

        for w in self.results_scroll.winfo_children():
            w.destroy()

        loader = ctk.CTkLabel(self.results_scroll, text=i18n.get("winget_searching"), text_color="gray")
        loader.pack(pady=20)
        self.update()

        def _search_thread():
            error_msg = None
            results = []
            try:
                results = self.winget_helper.search_packages(query)
            except Exception as e:
                error_msg = str(e)

            self.after(0, lambda: self._display_results(results, error=error_msg, filter_by=filter_by, query=query))

        threading.Thread(target=_search_thread, daemon=True).start()

    def _display_results(self, results, error=None, filter_by="All", query=""):
        for w in self.results_scroll.winfo_children():
            w.destroy()

        if error:
            err_label = ctk.CTkLabel(self.results_scroll, text=f"Error: {error}", text_color="red", wraplength=250)
            err_label.pack(pady=20, padx=10)
            self.results_count_label.configure(text="")
            return

        # Filter results based on selected filter
        if results and filter_by != "All" and query:
            query_lower = query.lower()
            filtered_results = []
            for app in results:
                if filter_by == "Name" and query_lower in app.get('Name', '').lower():
                    filtered_results.append(app)
                elif filter_by == "Package ID" and query_lower in app.get('Id', '').lower():
                    filtered_results.append(app)
                elif filter_by == "Publisher":
                    pkg_id = app.get('Id', '')
                    if '.' in pkg_id and query_lower in pkg_id.split('.')[0].lower():
                        filtered_results.append(app)
            results = filtered_results

        # Update results count
        count = len(results) if results else 0
        self.results_count_label.configure(text=f"Found {count} app{'s' if count != 1 else ''}")

        if not results:
            ctk.CTkLabel(self.results_scroll, text=i18n.get("winget_no_results")).pack(pady=20)
            return

        for app in results:
            # Clickable logic
            display_text = f"{app['Name']} ({app['Version']})\nID: {app['Id']}"
            b = ctk.CTkButton(self.results_scroll, text=display_text, anchor="w", fg_color="transparent", border_width=1,
                              text_color=("black", "white"),
                              command=lambda a=app: self._load_details(a))
            b.pack(fill="x", pady=2)

    def _load_details(self, app_info):
        for w in self.details_content.winfo_children():
            w.destroy()
        self.lbl_details_title.configure(text=app_info["Name"])

        loader = ctk.CTkLabel(self.details_content, text=i18n.get("winget_loading"), text_color="gray")
        loader.pack(pady=20)

        def _fetch():
            try:
                details = self.winget_helper.get_package_details(app_info["Id"])
                full_info = {**app_info, **details}
                self.after(0, lambda: self._show_full_details(full_info))
            except Exception as e:
                logger.error(f"Failed to get package details for {app_info.get('Id', 'Unknown')}: {e}", exc_info=True)
                # Show error state in UI
                error_msg = f"Package not found or error loading details: {str(e)}"
                self.after(0, lambda: self._show_error_state(error_msg, app_info))

        threading.Thread(target=_fetch, daemon=True).start()

    def _show_error_state(self, error_msg, app_info):
        """Show error state when package details cannot be loaded."""
        for w in self.details_content.winfo_children():
            w.destroy()
        self.lbl_details_title.configure(text=app_info.get("Name", "Unknown Package"))
        error_label = ctk.CTkLabel(self.details_content, text=error_msg, text_color="red", wraplength=400)
        error_label.pack(pady=20, padx=10)
        # Show basic info from search results
        basic_frame = ctk.CTkFrame(self.details_content, fg_color="transparent")
        basic_frame.pack(fill="x", pady=10, padx=10)
        ctk.CTkLabel(basic_frame, text=i18n.get("winget_filter_id") or "Package ID:", font=ctk.CTkFont(weight="bold"), width=100, anchor="w").pack(side="left")
        ctk.CTkLabel(basic_frame, text=app_info.get("Id", i18n.get("unknown") or "Unknown"), anchor="w").pack(side="left", fill="x", expand=True)
        basic_frame2 = ctk.CTkFrame(self.details_content, fg_color="transparent")
        basic_frame2.pack(fill="x", pady=2, padx=10)
        ctk.CTkLabel(basic_frame2, text=i18n.get("field_version") or "Version:", font=ctk.CTkFont(weight="bold"), width=100, anchor="w").pack(side="left")
        ctk.CTkLabel(basic_frame2, text=app_info.get("Version", i18n.get("unknown") or "Unknown"), anchor="w").pack(side="left", fill="x", expand=True)

    def _show_full_details(self, info):
        for w in self.details_content.winfo_children():
            w.destroy()

        def add_row(lbl, val, link=False):
            if not val:
                return
            f = ctk.CTkFrame(self.details_content, fg_color="transparent")
            f.pack(fill="x", pady=2)
            ctk.CTkLabel(f, text=lbl + ":", font=ctk.CTkFont(weight="bold"), width=100, anchor="w").pack(side="left")
            if link:
                ctk.CTkButton(f, text=val, fg_color="transparent", text_color="#3B8ED0", anchor="w", hover=False, height=20,
                              command=lambda: webbrowser.open(val)).pack(side="left", fill="x", expand=True)
            else:
                if len(val) > 50:
                    t = ctk.CTkTextbox(f, height=60, fg_color="transparent", wrap="word")
                    t.insert("0.0", val)
                    t.configure(state="disabled")
                    t.pack(side="left", fill="x", expand=True)
                else:
                    ctk.CTkLabel(f, text=val, anchor="w", wraplength=400).pack(side="left", fill="x", expand=True)

        add_row(i18n.get("field_version") or "Version", info.get("Version"))
        add_row(i18n.get("field_publisher") or "Publisher", info.get("Publisher") or info.get("publisher"))
        add_row(i18n.get("field_about") or "Description", info.get("Description") or info.get("description"))
        add_row(i18n.get("field_homepage") or "Homepage", info.get("Homepage") or info.get("homepage"), link=True)

        # Manifest URL Logic
        manifest_url = info.get("manifest_url")
        if not manifest_url and info.get("Id"):
             # Construct GitHub link
             pkg_id = info.get("Id")
             try:
                 parts = pkg_id.split('.', 1)
                 if len(parts) >= 2:
                     publisher = parts[0]
                     first_char = publisher[0].lower()
                     manifest_url = f"https://github.com/microsoft/winget-pkgs/tree/master/manifests/{first_char}/{publisher.replace('.', '/')}/{parts[1]}"
                 else:
                     manifest_url = f"https://github.com/microsoft/winget-pkgs/tree/master/manifests/{pkg_id[0].lower()}/{pkg_id}"
             except (IndexError, ValueError):
                 pass

        add_row("Manifest URL", manifest_url, link=True)

        add_row(i18n.get("field_license") or "License", info.get("License") or info.get("license"))
        add_row("License URL", info.get("LicenseUrl") or info.get("license_url"), link=True)
        add_row(i18n.get("field_type") or "Installer Type", info.get("InstallerType") or info.get("installer_type"))
        add_row("Release Date", info.get("ReleaseDate"))
        add_row("SHA256", info.get("sha256") or info.get("InstallerSha256"))

        # AutoUpdate Tip
        tip_text = i18n.get("winget_tip_autoupdate") or "Tip: Use Winget-AutoUpdate to keep apps fresh!"
        ctk.CTkLabel(self.details_content, text=tip_text, font=ctk.CTkFont(size=11, slant="italic"), text_color="gray", anchor="w").pack(pady=(20, 0), padx=10, fill="x")

        # Actions
        ctk.CTkLabel(self.details_content, text=i18n.get("winget_actions"), font=ctk.CTkFont(weight="bold", size=14)).pack(pady=(20, 10))

        actions_frame = ctk.CTkFrame(self.details_content)
        actions_frame.pack(fill="x", pady=10, padx=10)

        ctk.CTkButton(actions_frame, text="Copy Command", fg_color="gray",
                      command=lambda: self._copy_install_command(info)).pack(side="left", padx=5, pady=10, expand=True)

        ctk.CTkButton(actions_frame, text=i18n.get("winget_install_local"), fg_color="green",
                      command=lambda: self._install_local(info)).pack(side="left", padx=5, pady=10, expand=True)

        ctk.CTkButton(actions_frame, text=i18n.get("winget_deploy_intune"), fg_color="#0066CC",
                      command=lambda: self._deploy_menu(info)).pack(side="right", padx=5, pady=10, expand=True)

    def _install_local(self, info):
        scope = "machine"
        if messagebox.askyesno(i18n.get("winget_install_scope_title"), i18n.get("winget_install_scope_msg")):
            scope = "machine"
        else:
            scope = "user"

        cmd = f"winget install --id {info['Id']} --scope {scope} --accept-package-agreements --accept-source-agreements"  # noqa: F841

        top = ctk.CTkToplevel(self)
        top.title(i18n.get("winget_dl_title"))
        lbl = ctk.CTkLabel(top, text=f"{i18n.get('winget_dl_title')} {info['Name']}...")
        lbl.pack(pady=20, padx=20)

        def _run():
            success = self.winget_helper.install_package(info['Id'], scope)
            if success:
                self.after(0, lambda: messagebox.showinfo(i18n.get("winget_install_success_title"), f"{info['Name']} {i18n.get('winget_install_success_msg')}"))
            else:
                self.after(0, lambda: messagebox.showerror(i18n.get("winget_install_failed_title"), f"{i18n.get('winget_install_failed_msg')}"))
            self.after(0, top.destroy)

        threading.Thread(target=_run, daemon=True).start()

    def _copy_install_command(self, info):
        """Copy the winget install command to clipboard."""
        pkg_id = info.get('Id', '')
        command = f"winget install --id {pkg_id} --accept-package-agreements --accept-source-agreements"
        self.clipboard_clear()
        self.clipboard_append(command)
        messagebox.showinfo("Copied", f"Command copied to clipboard:\n{command}")

    def _deploy_menu(self, info):
        dialog = ctk.CTkToplevel(self)
        dialog.title(i18n.get("winget_deploy_dialog_title"))
        dialog.geometry("450x400")

        ctk.CTkLabel(dialog, text=f"{i18n.get('winget_deploy_dialog_title')} {info['Name']}", font=ctk.CTkFont(weight="bold")).pack(pady=10)
        ctk.CTkLabel(dialog, text=i18n.get("winget_deploy_select_method")).pack(pady=5)

        # 1. WAU
        def _method_wau():
            dialog.destroy()
            self._deploy_wau_promo(info)

        btn1 = ctk.CTkButton(dialog, text=i18n.get("winget_method_wau"), fg_color="green", command=_method_wau)
        btn1.pack(pady=(10, 5), fill="x", padx=20)
        ctk.CTkLabel(dialog, text=i18n.get("winget_method_wau_desc"), font=ctk.CTkFont(size=10)).pack(pady=(0, 10))

        # 2. Package
        def _method_package():
            dialog.destroy()
            self._deploy_package_start(info)

        btn2 = ctk.CTkButton(dialog, text=i18n.get("winget_method_pkg"), fg_color="#0066CC", command=_method_package)
        btn2.pack(pady=5, fill="x", padx=20)
        ctk.CTkLabel(dialog, text=i18n.get("winget_method_pkg_desc"), font=ctk.CTkFont(size=10)).pack(pady=(0, 10))

        # 3. Direct Script
        def _method_direct():
            dialog.destroy()
            self._deploy_direct_script(info)

        btn3 = ctk.CTkButton(dialog, text=i18n.get("winget_method_script"), fg_color="gray", command=_method_direct)
        btn3.pack(pady=5, fill="x", padx=20)
        ctk.CTkLabel(dialog, text=i18n.get("winget_method_script_desc"), font=ctk.CTkFont(size=10)).pack(pady=(0, 10))

    def _deploy_wau_promo(self, info):
        webbrowser.open("https://github.com/Romanitho/Winget-AutoUpdate")
        messagebox.showinfo(i18n.get("winget_wau_info_title"), i18n.get("winget_wau_info_msg"))

    def _deploy_direct_script(self, info):
        script_content = f"""<#
.NOTES
Generated by SwitchCraft via Winget Integration
App: {info['Name']}
ID: {info['Id']}
#>
$PackageId = "{info['Id']}"
$LogPath = "$env:ProgramData\\Microsoft\\IntuneManagementExtension\\Logs\\Winget-{info['Id']}.log"

Start-Transcript -Path $LogPath -Force

Write-Host "Installing $PackageId via Winget..."
$winget = Get-Command winget -ErrorAction SilentlyContinue
if (!$winget) {{
    Write-Error "Winget not found!"
    exit 1
}}

& winget install --id $PackageId --accept-package-agreements --accept-source-agreements --scope machine
$err = $LASTEXITCODE

Stop-Transcript
exit $err
"""
        tmp = tempfile.mkdtemp()
        script_path = Path(tmp) / "install.ps1"
        script_path.write_text(script_content, encoding="utf-8")

        save_path = ctk.filedialog.asksaveasfilename(defaultextension=".ps1", initialfile=f"Install-{info['Id']}.ps1", title=i18n.get("winget_create_script_btn"))
        if save_path:
            shutil.copy(script_path, save_path)
            shutil.rmtree(tmp)
            if messagebox.askyesno(i18n.get("winget_script_saved", path=""), i18n.get("winget_script_saved", path="Script saved") + "\n\nPackage Now?"):
                self.main_app.show_intune_tab(save_path, metadata=info)

    def _deploy_package_start(self, info):
        top = ctk.CTkToplevel(self)
        top.title(i18n.get("winget_dl_title"))
        ctk.CTkLabel(top, text=f"{i18n.get('winget_dl_title')} {info['Name']}...").pack(pady=20, padx=20)

        def _dl():
            tmp_dir = tempfile.mkdtemp()
            cmd = ["winget", "download", "--id", info["Id"], "--dir", tmp_dir, "--accept-source-agreements", "--accept-package-agreements"]
            import subprocess
            proc = subprocess.run(cmd, capture_output=True, text=True)

            if proc.returncode == 0:
                files = list(Path(tmp_dir).glob("*.*"))
                installer = None
                for f in files:
                    if f.suffix.lower() in [".exe", ".msi"]:
                        installer = f
                        break

                if installer:
                    dest_dir = Path.home() / "Downloads" / "SwitchCraft_Winget"
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest = dest_dir / installer.name
                    shutil.copy(installer, dest)

                    self.after(0, lambda: self._on_download_complete(dest, info))
                else:
                    self.after(0, lambda: messagebox.showerror(i18n.get("winget_dl_error_title"), i18n.get("winget_dl_error_no_file")))
            else:
                 self.after(0, lambda: messagebox.showerror(i18n.get("winget_dl_failed_title"), proc.stderr))
            self.after(0, top.destroy)

        threading.Thread(target=_dl, daemon=True).start()

    def _on_download_complete(self, filepath, info):
        if messagebox.askyesno(i18n.get("winget_dl_complete_title"), i18n.get("winget_dl_complete_msg", path=filepath)):
            self.main_app.start_analysis_tab(str(filepath))
