import os
import sys
import flet as ft
# WASM compatibility patches
if sys.platform == "emscripten":
    import pyodide_http
    pyodide_http.patch_all()
sys.path.insert(0, os.getcwd())
import switchcraft
switchcraft.IS_DEMO = True
import switchcraft.main
if __name__ == "__main__":
    ft.run(switchcraft.main.main, assets_dir="assets")
